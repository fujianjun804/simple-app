module.exports = {
	'msg':'hello world'
}
