// 修改城市
export const UPDATE_CITY = "updateCity"