import * as Types from '../action-types/userInfo'

export function update (data) {
	return {
		type: Types.UPDATE_CITY,
		date
	}
}